#include "player.h"
#include "compat.h"
#include "log.h"
#include <cstring>
#include <cerrno>
#include <vector>
#include <string>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>

#if defined(YTUI_MACOS)
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <thread>
#endif

namespace ytui {

Player::Player() {
    death_pipe_[0] = -1;
    death_pipe_[1] = -1;
}

Player::~Player() { stop(); }

bool Player::is_available() {
    return system("which mpv > /dev/null 2>&1") == 0;
}

// ─── Public API ───────────────────────────────────────────────────────────────

void Player::play(const std::string& url, const std::string& title, PlayMode mode) {
    stop();
    if (mode == PlayMode::Video)
        play_direct(url, title);
    else
        play_piped(url, title, mode);
}

void Player::stop() {
    kill_mpv();
    close_death_pipe();
    playing_ = false;
    paused_  = false;
    current_title_.clear();
#if defined(YTUI_MACOS)
    watcher_stop_.store(true);
    mpv_idle_.store(false);
    if (!ipc_path_.empty()) { unlink(ipc_path_.c_str()); ipc_path_.clear(); }
#endif
}

void Player::close_death_pipe() {
    if (death_pipe_[0] >= 0) { close(death_pipe_[0]); death_pipe_[0] = -1; }
    if (death_pipe_[1] >= 0) { close(death_pipe_[1]); death_pipe_[1] = -1; }
}

bool Player::toggle_pause() {
    if (!playing_ || mpv_pid_ <= 0) return false;
    if (paused_) {
        kill(-mpv_pid_, SIGCONT);
        paused_ = false;
        Log::write("Resumed pgid -%d", mpv_pid_);
    } else {
        kill(-mpv_pid_, SIGSTOP);
        paused_ = true;
        Log::write("Paused pgid -%d", mpv_pid_);
    }
    return paused_;
}

// ─── is_playing ───────────────────────────────────────────────────────────────
// FIX: old code only called waitpid(WNOHANG) on the tracked pid. When the user
// closes the mpv window the whole process group dies, but the shell wrapper pid
// may not have been reaped yet so WNOHANG returns 0 (still running) incorrectly,
// leaving "Playing <title>" stuck on screen.
//
// Fix: after waitpid says "still running", also probe the process group with
// kill(-pgid, 0). If errno == ESRCH the group is fully gone — mark stopped.

bool Player::is_playing() const {
    if (!playing_ || mpv_pid_ <= 0) return false;

#if defined(YTUI_MACOS)
    // IPC watcher detected that mpv went idle (video ended or window closed).
    // The process is likely still alive (Homebrew mpv quirk) — kill it now.
    if (mpv_idle_.load()) {
        Log::write("is_playing: mpv_idle set — killing zombie mpv pid %d", mpv_pid_);
        const_cast<Player*>(this)->kill_mpv();
        const_cast<Player*>(this)->playing_ = false;
        const_cast<Player*>(this)->mpv_idle_.store(false);
        if (!const_cast<Player*>(this)->ipc_path_.empty()) {
            unlink(const_cast<Player*>(this)->ipc_path_.c_str());
            const_cast<Player*>(this)->ipc_path_.clear();
        }
        return false;
    }
#endif

    int status = 0;
    pid_t r = waitpid(mpv_pid_, &status, WNOHANG);

    if (r == mpv_pid_) {
        const_cast<Player*>(this)->playing_ = false;
        const_cast<Player*>(this)->mpv_pid_ = -1;
        Log::write("is_playing: pid %d exited", r);
        return false;
    }

    if (r < 0) {
        // ECHILD: pid is gone entirely
        const_cast<Player*>(this)->playing_ = false;
        const_cast<Player*>(this)->mpv_pid_ = -1;
        return false;
    }

    // r == 0: pid not reaped yet — probe the process group too.
    // If kill(-pgid, 0) → ESRCH, every process in the group is dead.
    if (kill(-mpv_pid_, 0) < 0 && errno == ESRCH) {
        waitpid(mpv_pid_, &status, WNOHANG);
        const_cast<Player*>(this)->playing_ = false;
        const_cast<Player*>(this)->mpv_pid_ = -1;
        Log::write("is_playing: pgid -%d gone (ESRCH)", mpv_pid_);
        return false;
    }

    return true;
}

std::string Player::now_playing() const {
    if (is_playing()) return current_title_;
    return "";
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

static void child_setup(bool log_to_file,
                        int death_pipe_read_fd,
                        pid_t original_ppid,
                        int sync_pipe_write_fd) {
    setpgid(0, 0);

    if (sync_pipe_write_fd >= 0) {
        char byte = 1;
        ssize_t w = write(sync_pipe_write_fd, &byte, 1); (void)w;
    }

    if (compat::has_native_pdeathsig()) {
        compat::set_pdeathsig(SIGKILL);
        if (death_pipe_read_fd >= 0) close(death_pipe_read_fd);
    } else {
        if (death_pipe_read_fd >= 0)
            compat::fork_death_watchdog(death_pipe_read_fd, original_ppid);
    }

    int devnull = open("/dev/null", O_RDWR);
    if (devnull >= 0) {
        dup2(devnull, STDIN_FILENO);
        dup2(devnull, STDOUT_FILENO);
        if (!log_to_file)
            dup2(devnull, STDERR_FILENO);
        close(devnull);
    }

    if (log_to_file) {
        std::string el = Log::get_log_dir() + "/mpv.log";
        int ef = open(el.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (ef >= 0) { dup2(ef, STDERR_FILENO); close(ef); }
    }
}

static void setup_death_pipe(int death_pipe[2]) {
    death_pipe[0] = death_pipe[1] = -1;
    if (!compat::has_native_pdeathsig()) {
        if (compat::pipe_cloexec(death_pipe) < 0)
            Log::write("death pipe_cloexec failed: %s", strerror(errno));
    }
}

static bool wait_for_setpgid(int sync_read_fd, pid_t child_pid) {
    if (sync_read_fd < 0) return false;
    int flags = fcntl(sync_read_fd, F_GETFL, 0);
    if (flags >= 0) fcntl(sync_read_fd, F_SETFL, flags | O_NONBLOCK);
    char byte = 0;
    for (int i = 0; i < 500; i++) {
        ssize_t n = read(sync_read_fd, &byte, 1);
        if (n == 1) return true;
        if (n == 0) return false;
        if (errno != EAGAIN && errno != EWOULDBLOCK) return false;
        int st;
        if (waitpid(child_pid, &st, WNOHANG) == child_pid) return false;
        usleep(1000);
    }
    return false;
}

static std::string vol_flag(int v) {
    char buf[32];
    snprintf(buf, sizeof(buf), "--volume=%d", v);
    return buf;
}

// ─── resolve_stream_urls ──────────────────────────────────────────────────────
// FIX for slow open: the old play_direct passed a youtube.com URL + --ytdl=yes,
// which made mpv invoke yt-dlp internally to extract the stream URL. That entire
// extraction happens after the user clicks play, before the window opens — hence
// the 8-15 second blank wait.
//
// Instead: run yt-dlp -g here, get the raw HTTPS stream URLs, pass them directly
// to mpv with --ytdl=no. mpv gets a plain https:// URL it can start buffering
// immediately and the window opens within ~1 second.
//
// yt-dlp -g with a split format (bestvideo+bestaudio) returns two lines:
//   line 1: video stream URL
//   line 2: audio stream URL
// We pass the video URL as the main file and audio via --audio-file=.
//
// Falls back to --ytdl=yes if yt-dlp -g fails for any reason (private video,
// rate limit, geo-block) so nothing silently breaks.

struct StreamURLs {
    std::string video_url;
    std::string audio_url;
    bool ok = false;
};

static StreamURLs resolve_stream_urls(const std::string& youtube_url, int max_res,
                                      const std::string& cookie_args) {
    StreamURLs result;

    // Clamp max_res to the nearest valid YouTube stream height that is <= requested.
    // YouTube only publishes at 144, 240, 360, 480, 720, 1080, 1440, 2160.
    // Requesting e.g. 140 returns nothing; clamp up to 144 minimum.
    static const int valid_heights[] = {144, 240, 360, 480, 720, 1080, 1440, 2160};
    int clamped = valid_heights[0];  // floor default = 144
    for (int h : valid_heights) {
        if (h <= max_res) clamped = h;
    }

    char res_buf[16];
    snprintf(res_buf, sizeof(res_buf), "%d", clamped);

    if (clamped != max_res)
        Log::write("resolve: max_res=%d clamped to nearest valid height %d", max_res, clamped);

    // Correct yt-dlp format: bestvideo[height<=N]+bestaudio → 2 URLs from -g
    // Fallback: best combined stream at <=N, then absolute best
    std::string fmt = std::string("bestvideo[height<=") + res_buf +
                      "]+bestaudio/best[height<=" + res_buf + "]/best";

    std::string cmd =
        "yt-dlp -g --no-warnings --no-playlist "
        + (cookie_args.empty() ? "" : cookie_args + " ")
        + "-f '" + fmt + "' "
        "'" + youtube_url + "' 2>/dev/null";

    Log::write("resolve (max_res=%d->%d cookies=%s): %s",
               max_res, clamped,
               cookie_args.empty() ? "no" : "yes",
               cmd.c_str());

    FILE* p = popen(cmd.c_str(), "r");
    if (!p) {
        Log::write("resolve: popen failed: %s", strerror(errno));
        return result;
    }

    char buf[8192];
    std::string line1, line2;

    if (fgets(buf, sizeof(buf), p)) {
        line1 = buf;
        while (!line1.empty() && (line1.back()=='\n'||line1.back()=='\r'))
            line1.pop_back();
    }
    if (fgets(buf, sizeof(buf), p)) {
        line2 = buf;
        while (!line2.empty() && (line2.back()=='\n'||line2.back()=='\r'))
            line2.pop_back();
    }
    pclose(p);

    if (line1.empty()) {
        Log::write("resolve: no output — private/unavailable/rate-limited?");
        return result;
    }

    if (!line2.empty()) {
        result.video_url = line1;
        result.audio_url = line2;
        Log::write("resolve: video=%.80s...", line1.c_str());
        Log::write("resolve: audio=%.80s...", line2.c_str());
    } else {
        // Combined stream (e.g. live, or fallback format)
        result.video_url = line1;
        result.audio_url = "";
        Log::write("resolve: combined=%.80s...", line1.c_str());
    }

    result.ok = true;
    return result;
}

// ─── play_piped (audio modes) ─────────────────────────────────────────────────

void Player::play_piped(const std::string& url, const std::string& title, PlayMode mode) {
    std::string vol = vol_flag(opts_.volume);

    std::string ytdlp_cmd =
        "yt-dlp --no-warnings --no-playlist "
        + (opts_.cookie_args.empty() ? "" : opts_.cookie_args + " ")
        + "-f 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio' "
        "--audio-quality 0 "
        "-o - '" + url + "'";

    std::string mpv_cmd = "mpv --no-video --no-terminal --input-terminal=no " + vol;

    if (!opts_.no_cache) {
        mpv_cmd += " --audio-buffer=2 --cache=yes --demuxer-max-bytes=50M";
    } else {
        mpv_cmd += " --cache=no";
        Log::write("no-cache mode");
    }

    mpv_cmd += " --audio-pitch-correction=yes";

    if (opts_.no_hardware_accel) {
        mpv_cmd += " --hwdec=no";
        Log::write("no-ha mode");
    }

    if (mode == PlayMode::AudioLoop) mpv_cmd += " --loop=inf";
    mpv_cmd += " -";

    std::string cmd = ytdlp_cmd + " | " + mpv_cmd;
    Log::write("Piped play: %s", cmd.c_str());

    close_death_pipe();
    setup_death_pipe(death_pipe_);

    int sync_pipe[2] = {-1, -1};
    if (compat::pipe_cloexec(sync_pipe) < 0) {
        Log::write("sync pipe failed: %s", strerror(errno));
        sync_pipe[0] = sync_pipe[1] = -1;
    }

    pid_t original_ppid = getpid();
    pid_t pid = fork();

    if (pid == 0) {
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (death_pipe_[1] >= 0) close(death_pipe_[1]);
        child_setup(Log::is_logdump(), death_pipe_[0], original_ppid, sync_pipe[1]);
        execlp("sh", "sh", "-c", cmd.c_str(), nullptr);
        _exit(127);
    } else if (pid > 0) {
        if (sync_pipe[1] >= 0) { close(sync_pipe[1]); sync_pipe[1] = -1; }
        if (death_pipe_[0] >= 0) { close(death_pipe_[0]); death_pipe_[0] = -1; }
        bool pgid_ok = wait_for_setpgid(sync_pipe[0], pid);
        if (sync_pipe[0] >= 0) { close(sync_pipe[0]); sync_pipe[0] = -1; }
        Log::write("Piped play pid=%d pgid_sync=%s", pid, pgid_ok ? "ok" : "timeout");
        mpv_pid_       = pid;
        playing_       = true;
        current_title_ = title;
    } else {
        Log::write("fork failed: %s", strerror(errno));
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (sync_pipe[1] >= 0) close(sync_pipe[1]);
        close_death_pipe();
    }
}

// ─── play_direct (video mode) ─────────────────────────────────────────────────

void Player::play_direct(const std::string& url, const std::string& title) {
    std::string vol = vol_flag(opts_.volume);

    // Pre-resolve stream URLs so mpv gets direct https:// and opens immediately.
    // The TUI is already showing "Loading..." at this point.
    StreamURLs streams = resolve_stream_urls(url, opts_.max_res, opts_.cookie_args);

    // Use same height clamping as resolve_stream_urls (YouTube only has 144/240/360/480/720/1080/...)
    static const int valid_heights_pd[] = {144, 240, 360, 480, 720, 1080, 1440, 2160};
    int clamped_res = valid_heights_pd[0];
    for (int h : valid_heights_pd) { if (h <= opts_.max_res) clamped_res = h; }
    char res_buf[16];
    snprintf(res_buf, sizeof(res_buf), "%d", clamped_res);
    std::string slow_fmt = std::string("bestvideo[height<=") + res_buf +
                           "]+bestaudio/best[height<=" + res_buf + "]/best";

    std::vector<std::string> args = {
        "mpv",
#if !defined(YTUI_MACOS)
        // On macOS, mpv opens a Cocoa window automatically for video content.
        // --force-window=yes triggers extra AppKit/run-loop initialisation that
        // adds several seconds of startup delay before the first frame appears.
        "--force-window=yes",
#endif
#if defined(YTUI_MACOS)
        // Prevent the user's ~/.config/mpv/mpv.conf from overriding our flags
        // (e.g. keep-open=yes would defeat --keep-open=no below and cause the
        // is_playing() freeze bug on every video).
        "--no-config",
#endif
        "--keep-open=no",       // exit when window is closed or playback ends.
                                // On macOS (Homebrew mpv), the default changed:
                                // closing the window now keeps the process alive.
                                // Without this, is_playing() never detects death
                                // and the main loop stays frozen indefinitely.
        "--no-terminal",        // suppress mpv's terminal status output
        "--input-terminal=no",  // stop mpv opening /dev/tty for keyboard input.
                                // Without this, mpv sets VMIN=1/VTIME=0 on /dev/tty
                                // which blocks ytcui's getch() even with timeout(100).
        vol,
        "--geometry=854x480",
        "--autofit-larger=70%",
        "--autofit-smaller=640x360",
        "--title=" + title,
    };

#if defined(YTUI_MACOS)
    // Add IPC socket so we can detect when mpv goes idle via start_ipc_watcher().
    // Homebrew mpv keeps the process alive after window close even with
    // --keep-open=no; the IPC socket is the only reliable way to observe the
    // "playback ended" event and unblock the main loop.
    ipc_path_ = "/tmp/ytcui-mpv-" + std::to_string(getpid()) + ".sock";
    unlink(ipc_path_.c_str());  // clear any stale socket
    args.push_back("--input-ipc-server=" + ipc_path_);
    mpv_idle_.store(false);
    watcher_stop_.store(false);
#endif

    if (streams.ok) {
        // Fast path: direct stream URLs, mpv opens window immediately
        args.push_back("--ytdl=no");
        if (!opts_.no_cache) {
            args.push_back("--cache=yes");
            args.push_back("--demuxer-max-bytes=100M");
        } else {
            args.push_back("--cache=no");
        }
        if (opts_.no_hardware_accel) {
            args.push_back("--hwdec=no");
            
        }
        args.push_back(streams.video_url);
        if (!streams.audio_url.empty())
            args.push_back("--audio-file=" + streams.audio_url);

        Log::write("Direct play (fast): vol=%d hwdec=%s cache=%s",
                   opts_.volume,
                   opts_.no_hardware_accel ? "no" : "auto",
                   opts_.no_cache ? "no" : "yes");
    } else {
        // Slow fallback: let mpv call yt-dlp itself
        Log::write("Direct play (slow fallback --ytdl=yes, max_res=%d): %s", opts_.max_res, url.c_str());
        args.push_back("--ytdl=yes");
        args.push_back("--ytdl-format=" + slow_fmt);
        // Pass cookies through to mpv's internal yt-dlp call
        if (!opts_.cookie_args.empty()) {
            // cookie_args is e.g. "--cookies-from-browser edge"
            // mpv accepts yt-dlp args via --ytdl-raw-options=key=value
            // Parse out the browser name after "--cookies-from-browser "
            const std::string prefix = "--cookies-from-browser ";
            if (opts_.cookie_args.rfind(prefix, 0) == 0) {
                std::string browser = opts_.cookie_args.substr(prefix.size());
                args.push_back("--ytdl-raw-options=cookies-from-browser=" + browser);
            }
        }
        if (!opts_.no_cache) {
            args.push_back("--cache=yes");
            args.push_back("--demuxer-max-bytes=100M");
        } else {
            args.push_back("--cache=no");
        }
        if (opts_.no_hardware_accel) {
            args.push_back("--hwdec=no");
            
        }
        args.push_back(url);
    }

    std::vector<const char*> argv;
    for (auto& a : args) argv.push_back(a.c_str());
    argv.push_back(nullptr);

    int exec_pipe[2] = {-1, -1};
    if (compat::pipe_cloexec(exec_pipe) < 0) {
        Log::write("exec pipe failed: %s", strerror(errno));
        return;
    }

    int sync_pipe[2] = {-1, -1};
    if (compat::pipe_cloexec(sync_pipe) < 0) {
        Log::write("sync pipe failed: %s", strerror(errno));
        sync_pipe[0] = sync_pipe[1] = -1;
    }

    close_death_pipe();
    setup_death_pipe(death_pipe_);

    pid_t original_ppid = getpid();
    pid_t pid = fork();

    if (pid == 0) {
        close(exec_pipe[0]);
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (death_pipe_[1] >= 0) close(death_pipe_[1]);
        child_setup(Log::is_logdump(), death_pipe_[0], original_ppid, sync_pipe[1]);
        execvp("mpv", (char* const*)argv.data());
        int err = errno;
        ssize_t w = write(exec_pipe[1], &err, sizeof(err)); (void)w;
        _exit(127);
    } else if (pid > 0) {
        close(exec_pipe[1]);
        if (sync_pipe[1] >= 0) { close(sync_pipe[1]); sync_pipe[1] = -1; }
        if (death_pipe_[0] >= 0) { close(death_pipe_[0]); death_pipe_[0] = -1; }

        bool pgid_ok = wait_for_setpgid(sync_pipe[0], pid);
        if (sync_pipe[0] >= 0) { close(sync_pipe[0]); sync_pipe[0] = -1; }

        int child_errno = 0;
        ssize_t n = read(exec_pipe[0], &child_errno, sizeof(child_errno));
        close(exec_pipe[0]);

        if (n > 0) {
            Log::write("mpv exec failed: %s", strerror(child_errno));
            waitpid(pid, nullptr, 0);
            close_death_pipe();
            return;
        }

        Log::write("Direct play pid=%d pgid_sync=%s", pid, pgid_ok ? "ok" : "timeout");
        mpv_pid_       = pid;
        playing_       = true;
        current_title_ = title;
#if defined(YTUI_MACOS)
        start_ipc_watcher();
#endif
    } else {
        close(exec_pipe[0]); close(exec_pipe[1]);
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (sync_pipe[1] >= 0) close(sync_pipe[1]);
        close_death_pipe();
        Log::write("fork failed: %s", strerror(errno));
    }
}

void Player::play_xdg(const std::string& url, const std::string& title) {
    Log::write("xdg/open: %s", url.c_str());

    close_death_pipe();
    setup_death_pipe(death_pipe_);

    int sync_pipe[2] = {-1, -1};
    compat::pipe_cloexec(sync_pipe);

    pid_t original_ppid = getpid();
    pid_t pid = fork();

    if (pid == 0) {
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (death_pipe_[1] >= 0) close(death_pipe_[1]);
        child_setup(false, death_pipe_[0], original_ppid, sync_pipe[1]);
#if defined(YTUI_MACOS)
        execlp("open", "open", url.c_str(), nullptr);
#else
        execlp("xdg-open", "xdg-open", url.c_str(), nullptr);
#endif
        _exit(127);
    } else if (pid > 0) {
        if (sync_pipe[1] >= 0) { close(sync_pipe[1]); sync_pipe[1] = -1; }
        if (death_pipe_[0] >= 0) { close(death_pipe_[0]); death_pipe_[0] = -1; }
        wait_for_setpgid(sync_pipe[0], pid);
        if (sync_pipe[0] >= 0) { close(sync_pipe[0]); sync_pipe[0] = -1; }
        mpv_pid_       = pid;
        playing_       = true;
        current_title_ = title;
    } else {
        if (sync_pipe[0] >= 0) close(sync_pipe[0]);
        if (sync_pipe[1] >= 0) close(sync_pipe[1]);
        close_death_pipe();
        Log::write("fork failed: %s", strerror(errno));
    }
}

#if defined(YTUI_MACOS)
// ─── start_ipc_watcher ────────────────────────────────────────────────────────
// Background thread with two jobs:
//
// 1. RE-ASSERT TTY (~250 ms after fork)
//    macOS mpv reopens /dev/tty and re-enables ICANON even with
//    --input-terminal=no.  ICANON makes the kernel buffer lines, so select()
//    never fires until Enter is pressed — ncurses timeout(100) is useless and
//    getch() hangs forever.  Calling tcsetattr(TCSANOW, saved_termios) from
//    this thread clears ICANON and immediately unblocks the main thread.
//    Only tcsetattr() is called here — no ncurses calls (not thread-safe).
//    The main thread calls restore_terminal() fully on the next iteration.
//
// 2. MONITOR IPC SOCKET FOR IDLE
//    mpv emits {"event":"property-change","name":"idle-active","data":true}
//    when the video ends or the window is closed.  On detection, set
//    mpv_idle_=true.  is_playing() checks this flag, kills the zombie process
//    (Homebrew mpv stays alive after window close even with --keep-open=no),
//    and returns false — allowing the main loop's was_playing→stopped edge to
//    fire restore_terminal() normally.

void Player::start_ipc_watcher() {
    std::string path = ipc_path_;

    // Grab our own /dev/tty fd for the tcsetattr restore.  Not sharing tui's
    // fd across threads — any fd to the same controlling tty is equivalent for
    // tcsetattr purposes (it affects the session, not the fd).
    int tty_fd = open("/dev/tty", O_RDWR | O_CLOEXEC);
    struct termios saved_tios{};
    bool tios_ok = (tty_fd >= 0 && tcgetattr(tty_fd, &saved_tios) == 0);
    if (!tios_ok)
        Log::write("ipc_watcher: could not save tty state (tty_fd=%d)", tty_fd);

    std::thread([this, path, tty_fd, saved_tios, tios_ok]() mutable {

        // ── Phase 1: tty restore ─────────────────────────────────────────────
        // Sleep 250 ms then fire tcsetattr.  If mpv already corrupted the tty,
        // this clears ICANON/raw and unblocks the main thread immediately.
        // We keep repeating every ~2 s as long as mpv is running, because some
        // builds of Homebrew mpv re-assert ICANON more than once.
        for (int tick = 0; tick < 30 && !watcher_stop_.load(); tick++) {
            usleep(100000);  // 100 ms
        }
        if (tios_ok && !watcher_stop_.load()) {
            // Clear ICANON: restore the pre-ncurses termios so getch() works.
            struct termios raw = saved_tios;
            raw.c_lflag &= ~(tcflag_t)(ICANON | ECHO | ECHOE | ECHOK | ECHONL | ISIG);
            raw.c_cc[VMIN]  = 1;
            raw.c_cc[VTIME] = 0;
            tcsetattr(tty_fd, TCSANOW, &raw);
            Log::write("ipc_watcher: tty ICANON cleared");
        }

        // ── Phase 2: wait for the IPC socket to appear ───────────────────────
        bool found = false;
        for (int i = 0; i < 80 && !watcher_stop_.load(); i++) {
            usleep(100000);
            struct stat st;
            if (stat(path.c_str(), &st) == 0) { found = true; break; }
        }
        if (!found) {
            Log::write("ipc_watcher: IPC socket never appeared — giving up");
            goto done;
        }
        Log::write("ipc_watcher: IPC socket appeared, connecting");

        {
            int sock = socket(AF_UNIX, SOCK_STREAM, 0);
            if (sock < 0) {
                Log::write("ipc_watcher: socket() failed: %s", strerror(errno));
                goto done;
            }

            struct sockaddr_un addr{};
            addr.sun_family = AF_UNIX;
            strncpy(addr.sun_path, path.c_str(), sizeof(addr.sun_path) - 1);

            if (connect(sock, reinterpret_cast<struct sockaddr*>(&addr),
                        sizeof(addr)) < 0) {
                Log::write("ipc_watcher: connect() failed: %s", strerror(errno));
                close(sock);
                goto done;
            }
            Log::write("ipc_watcher: connected");

            // Subscribe to idle-active property (fires on end-of-file / window close).
            const char* sub = "{\"command\":[\"observe_property\",1,\"idle-active\"]}\n";
            ssize_t sw = write(sock, sub, strlen(sub)); (void)sw;

            char buf[4096];
            int tty_re_tick = 0;

            while (!watcher_stop_.load()) {
                fd_set rfds;
                FD_ZERO(&rfds);
                FD_SET(sock, &rfds);
                struct timeval tv = {0, 300000};  // 300 ms poll
                int ret = select(sock + 1, &rfds, nullptr, nullptr, &tv);

                if (ret < 0) { Log::write("ipc_watcher: select error"); break; }

                if (ret == 0) {
                    // Timeout — periodically re-clear ICANON in case mpv reset it.
                    if (tios_ok && ++tty_re_tick >= 7) {
                        struct termios raw = saved_tios;
                        raw.c_lflag &= ~(tcflag_t)(ICANON | ECHO);
                        raw.c_cc[VMIN]  = 1;
                        raw.c_cc[VTIME] = 0;
                        tcsetattr(tty_fd, TCSANOW, &raw);
                        tty_re_tick = 0;
                    }
                    continue;
                }

                ssize_t n = read(sock, buf, sizeof(buf) - 1);
                if (n <= 0) {
                    // EOF — mpv closed the socket (process exiting or done).
                    Log::write("ipc_watcher: socket EOF — mpv done");
                    if (!watcher_stop_.load()) mpv_idle_.store(true);
                    break;
                }
                buf[n] = '\0';

                // Look for idle-active=true or end-file in the JSON lines.
                if ((strstr(buf, "\"idle-active\"") && strstr(buf, "true")) ||
                     strstr(buf, "\"end-file\"")) {
                    Log::write("ipc_watcher: playback ended (idle/end-file)");
                    if (!watcher_stop_.load()) mpv_idle_.store(true);
                    break;
                }
            }
            close(sock);
        }

    done:
        if (tty_fd >= 0) close(tty_fd);
        Log::write("ipc_watcher: thread done");
    }).detach();
}
#endif

void Player::kill_mpv() {
    if (mpv_pid_ <= 0) return;
    Log::write("Killing pgid -%d", mpv_pid_);
    kill(-mpv_pid_, SIGTERM);
    int status;
    pid_t r = waitpid(mpv_pid_, &status, WNOHANG);
    if (r == 0) {
        usleep(300000);
        r = waitpid(mpv_pid_, &status, WNOHANG);
        if (r == 0) {
            kill(-mpv_pid_, SIGKILL);
            waitpid(mpv_pid_, &status, 0);
        }
    }
    mpv_pid_ = -1;
}

} // namespace ytui
