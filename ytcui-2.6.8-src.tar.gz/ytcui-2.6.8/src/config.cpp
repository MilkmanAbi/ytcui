#include "config.h"
#include "log.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <cstdlib>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>

namespace ytui {
using json = nlohmann::json;

// ─── Helpers ──────────────────────────────────────────────────────────────────

std::string Config::config_dir() {
    const char* xdg = std::getenv("XDG_CONFIG_HOME");
    if (xdg && xdg[0] != '\0') return std::string(xdg) + "/ytcui";
    const char* home = std::getenv("HOME");
    return std::string(home ? home : ".") + "/.config/ytcui";
}

static void ensure_dir(const std::string& dir) {
    // mkdir -p without shelling out
    std::string p;
    for (size_t i = 0; i <= dir.size(); i++) {
        if (i == dir.size() || dir[i] == '/') {
            if (!p.empty()) {
                int r = mkdir(p.c_str(), 0755);
                if (r < 0 && errno != EEXIST)
                    Log::write("mkdir %s: %s", p.c_str(), strerror(errno));
            }
        }
        if (i < dir.size()) p += dir[i];
    }
}

// ─── Load ─────────────────────────────────────────────────────────────────────

void Config::load() {
    std::ifstream f(config_path());
    if (!f.is_open()) return;
    try {
        auto j = json::parse(f);

        // ── results / search ─────────────────────────────────────────────
        if (j.contains("max_results") && j["max_results"].is_number_integer())
            max_results = j["max_results"].get<int>();
        if (j.contains("sort_by") && j["sort_by"].is_string())
            sort_by = j["sort_by"].get<std::string>();
        if (j.contains("filter_type") && j["filter_type"].is_string())
            filter_type = j["filter_type"].get<std::string>();
        if (j.contains("filter_dur") && j["filter_dur"].is_string())
            filter_dur = j["filter_dur"].get<std::string>();

        // ── appearance ───────────────────────────────────────────────────
        if (j.contains("theme") && j["theme"].is_string())
            theme_name = j["theme"].get<std::string>();
        if (j.contains("grayscale") && j["grayscale"].is_boolean())
            grayscale = j["grayscale"].get<bool>();

        // ── player flags ─────────────────────────────────────────────────
        if (j.contains("no_hardware_accel") && j["no_hardware_accel"].is_boolean())
            no_hardware_accel = j["no_hardware_accel"].get<bool>();
        if (j.contains("no_cache") && j["no_cache"].is_boolean())
            no_cache = j["no_cache"].get<bool>();
        if (j.contains("volume") && j["volume"].is_number_integer())
            volume = j["volume"].get<int>();
        if (j.contains("max_res") && j["max_res"].is_number_integer())
            max_res = j["max_res"].get<int>();
        if (j.contains("prefer_audio") && j["prefer_audio"].is_boolean())
            prefer_audio = j["prefer_audio"].get<bool>();

        // ── paths ────────────────────────────────────────────────────────
        if (j.contains("ytdlp_path") && j["ytdlp_path"].is_string())
            ytdlp_path = j["ytdlp_path"].get<std::string>();
        if (j.contains("mpv_path") && j["mpv_path"].is_string())
            mpv_path = j["mpv_path"].get<std::string>();

    } catch (const std::exception& e) {
        Log::write("config load error: %s", e.what());
    }
}

// ─── Save ─────────────────────────────────────────────────────────────────────

void Config::save() {
    std::string dir = config_dir();
    ensure_dir(dir);

    json j;

    // ── results / search ─────────────────────────────────────────────────
    j["max_results"]       = max_results;
    j["sort_by"]           = sort_by;
    j["filter_type"]       = filter_type;
    j["filter_dur"]        = filter_dur;

    // ── appearance ───────────────────────────────────────────────────────
    j["theme"]             = theme_name;
    j["grayscale"]         = grayscale;

    // ── player flags ─────────────────────────────────────────────────────
    j["no_hardware_accel"] = no_hardware_accel;
    j["no_cache"]          = no_cache;
    j["volume"]            = volume;
    j["max_res"]           = max_res;
    j["prefer_audio"]      = prefer_audio;

    // ── paths ────────────────────────────────────────────────────────────
    j["ytdlp_path"]        = ytdlp_path;
    j["mpv_path"]          = mpv_path;

    std::ofstream f(config_path());
    if (!f.is_open()) {
        Log::write("config save: could not open %s for writing", config_path().c_str());
        return;
    }
    f << j.dump(2) << "\n";
    Log::write("config saved to %s", config_path().c_str());
}

} // namespace ytui
