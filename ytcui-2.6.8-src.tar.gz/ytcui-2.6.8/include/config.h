#pragma once

#include <string>
#include "theme.h"

namespace ytui {

struct Config {
    // ── Search / results ─────────────────────────────────────────────────
    int  max_results  = 15;
    std::string sort_by     = "";
    std::string filter_type = "";
    std::string filter_dur  = "";

    // ── Appearance ───────────────────────────────────────────────────────
    std::string theme_name  = "default";
    bool grayscale          = false;   // legacy alias → theme=grayscale

    // ── Player / playback flags (saved by --configwrite) ─────────────────
    bool no_hardware_accel  = false;   // --no-ha
    bool no_cache           = false;   // --no-cache
    int  volume             = 80;      // --volume
    int  max_res            = 1080;    // --max-res
    bool prefer_audio       = false;   // future: open audio by default

    // ── Paths (advanced) ─────────────────────────────────────────────────
    std::string ytdlp_path  = "yt-dlp";
    std::string mpv_path    = "mpv";

    // ── Helpers ──────────────────────────────────────────────────────────
    Theme get_theme() const {
        if (grayscale) return Theme::Grayscale;
        return string_to_theme(theme_name);
    }

    void load();
    void save();

    // config dir: $XDG_CONFIG_HOME/ytcui  or  ~/.config/ytcui
    static std::string config_dir();
    static std::string config_path() { return config_dir() + "/config.json"; }
};

} // namespace ytui
